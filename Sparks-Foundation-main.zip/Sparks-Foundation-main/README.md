## Basic Banking System
I have created frontend of a basic banking system.
I have focused more on improving the UI

#### demo link :-[here](https://basic-bank.netlify.app/)



